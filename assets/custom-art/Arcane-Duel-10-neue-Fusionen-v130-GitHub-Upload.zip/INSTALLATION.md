Arcane-Duel · 10 neue reguläre Fusionen (v130)
ZIP unverändert unter assets/custom-art/ nach development hochladen.
Ein GitHub-Workflow wird anschließend die Bilder prüfen, extrahieren und die Karten-ID 752–761 aktivieren.
Keine festen Rollentags: Die Fusion bekommt ihre Rolle nur aus den Fusionsmaterialien.
