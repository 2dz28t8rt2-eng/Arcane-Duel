# Arcane Duel · 10 Lategame-Artworks v11.7

Dieses Paket enthält zehn **originale Illustrationen**, ohne die in den bisherigen Kartenentwürfen eingebrannten Zusatzeffekte oder zu hohen ATK-/DEF-Werte.

Die Kartendaten, Namen, Rollen, Seltenheit, Stufen und korrekte Statistikberechnung wurden bereits im GitHub-Branch `development` vorbereitet. Aus Qualitäts- und Kompatibilitätsgründen bleiben die zehn neuen Karten bis zur Installation der Bilddateien noch **nicht aktiviert**; so tauchen keine Platzhalterbilder auf und bestehende Saves/Tests bleiben unberührt.

## Einbau
1. Entpacken.
2. Auf GitHub den Branch `development` auswählen und im Verzeichnis `assets/custom-art/lategame-v117/` die **10 .webp-Dateien** ablegen (nicht die .zip-Datei).
3. Danach die Karteninstallation mit dem Bildfreigabe-Schalter `ARTWORKS_COMPLETE=true` in `assets/lategame-noeffects-v117.js` und `assets/collection-v3-lategame-v117.js` aktivieren (oder diese Aktivierung von ChatGPT durchführen lassen).
4. CI-Tests durchführen und Entwicklungsversion mit Strg+F5 aktualisieren.

Die korrekten Basiswerte stehen in `manifest.json`. Das Spiel berechnet Zusatzboni separat über seine bestehenden Perk-/Rollenregeln; keine der zehn Karten besitzt eine eigene Sonderfähigkeit.
