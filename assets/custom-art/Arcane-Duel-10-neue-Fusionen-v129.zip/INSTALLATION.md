# Arcane Duel Fusion Wave II

Bitte diese ZIP auf GitHub in den Ordner `assets/custom-art/` hochladen, nicht entpacken.
Der Installer auf development entpackt das verifizierte ZIP und aktiviert die Karten automatisch.
